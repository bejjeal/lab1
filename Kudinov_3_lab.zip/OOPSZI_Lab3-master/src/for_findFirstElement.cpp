#include <math.h>
#include "func.h"

namespace for_loop
{
	int findFirstElement(double eps)
	{
		double i;

		for(i = 0; fabs(a(i)) >= eps; i++) { }

		return i;
	}
}
