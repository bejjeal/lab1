#include <math.h>

double a(int i)
{
	return pow(-1, i) * ( (i + 1) / (pow(3, i) + pow(2, i)) );
}
