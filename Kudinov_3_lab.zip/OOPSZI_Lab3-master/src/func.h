double a(int i);

namespace for_loop
{
	double summ(int n);
	double summ2(double eps);
	void print(int n, int k);
	int findFirstElement(double eps);
	int findFirstNegativeElement(double eps);
}

namespace while_loop
{
	double summ(int n);
	double summ2(double eps);
	void print(int n, int k);
	int findFirstElement(double eps);
	int findFirstNegativeElement(double eps);
}

namespace do_while_loop
{
	double summ(int n);
	double summ2(double eps);
	void print(int n, int k);
	int findFirstElement(double eps);
	int findFirstNegativeElement(double eps);
}
