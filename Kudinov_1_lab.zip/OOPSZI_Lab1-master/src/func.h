void f();
extern double x, y;
